<?php
	$base_url = "http://180.243.231.8:8085/kerjalokal/";
	$core_url = "http://180.243.231.8:8085/infokerja_core/";
?>