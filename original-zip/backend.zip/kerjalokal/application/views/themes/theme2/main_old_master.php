<?php echo $header; ?>
<div>
<?php echo $content; ?>
</div>
<div>
<?php echo $footer; ?>
</div>
