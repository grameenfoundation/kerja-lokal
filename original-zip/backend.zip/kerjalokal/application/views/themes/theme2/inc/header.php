<?php  if ( ! defined('BASEPATH')) exit('No direct access allowed'); ?>



<!--<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>.:Infokerja:.</title>

<script type="text/javascript" src="<?php echo base_url() . "themes/theme2/js/jquery.js"; ?>"></script>
<script type="text/javascript" src="<?php echo base_url() . "themes/theme2/js/easySlider1.7.js"; ?>"></script>

<script type="text/javascript" src="<?php echo base_url() . "themes/theme2/javascript/dropdown.js"; ?>"></script>


<script type="text/javascript">
	/*	SLIDER FOR SLIDESHOR	*/
	$(document).ready(function(){	
		$("#slider").easySlider({
			auto: true, 
			continuous: true,
			numeric: true
		});
	});	
</script>
	
<link href="<?php echo base_url() . "themes/theme2/css/screen.css"; ?>" rel="stylesheet" type="text/css" media="screen" />	

</head>

<body>

<table width="950" height="211" border="1" align="center" style="border : 1px solid #e0e0e0;">
  <tr>
    <th height="27" scope="col" style="border : 1px solid #e0e0e0;" align="left">RSS | Contact US | Patnership | Sitemap | Follow US | Bookmark & Share</th>
  </tr>
  <tr>
    <th height="121" scope="col" style="border : 1px solid #e0e0e0;" align="left">
    <table style="border : 1px solid #e0e0e0;" width="273" height="77" align="right">
      <tr>
        <th style="border : 1px solid #e0e0e0;" scope="col">Bakrie Telecom</th>
        <th style="border : 1px solid #e0e0e0;" scope="col">Quaicomm</th>
      </tr>
      <tr>
        <th style="border : 1px solid #e0e0e0;" scope="row">RUMA</th>
        <th style="border : 1px solid #e0e0e0;">Grameen Fondation</td>
      </tr>
    </table>
    <h1>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;INFO KERJA</h1>
    
    </th>
  </tr>
  <tr>
    <th height="25" scope="col" style="border : 1px solid #e0e0e0;" width="100%">
   	  	<ul id="sddm">
            <li><a href="#" onmouseover="mopen('m1')" onmouseout="mclosetime()">Home</a>
                <div id="m1" onmouseover="mcancelclosetime()" onmouseout="mclosetime()">
                <a href="#">HTML DropDown</a>
                <a href="#">DHTML DropDown menu</a>
                <a href="#">JavaScript DropDown</a>
                <a href="#">DropDown Menu</a>
                <a href="#">CSS DropDown</a>
                </div>
            </li>
            <li><a href="#" onmouseover="mopen('m2')" onmouseout="mclosetime()">About</a>
                <div id="m2" onmouseover="mcancelclosetime()" onmouseout="mclosetime()">
                <a href="#">ASP Dropdown</a>
                <a href="#">Pulldown menu</a>
                <a href="#">AJAX dropdown</a>
                <a href="#">DIV dropdown</a>
                </div>
            </li>
            <li><a href="#" onmouseover="mopen('m3')" onmouseout="mclosetime()">Learn</a>
                <div id="m3" onmouseover="mcancelclosetime()" onmouseout="mclosetime()">
                <a href="#">Visa Credit Card</a>
                <a href="#">Paypal</a>
                </div>
            </li>
            <li><a href="#" onmouseover="mopen('m4')" onmouseout="mclosetime()">For Employer</a>
                <div id="m4" onmouseover="mcancelclosetime()" onmouseout="mclosetime()">
                <a href="#">Download Help File</a>
                <a href="#">Read online</a>
                </div>
            </li>
            <li><a href="#" onmouseover="mopen('m5')" onmouseout="mclosetime()">Support Forum</a>
                <div id="m5" onmouseover="mcancelclosetime()" onmouseout="mclosetime()">
                <a href="#">E-mail</a>
                <a href="#">Submit Request Form</a>
                <a href="#">Call Center</a>
                </div>
            </li>
            <li><a href="#" onmouseover="mopen('m6')" onmouseout="mclosetime()">News & Events</a>
            	<div id="m6" onmouseover="mcancelclosetime()" onmouseout="mclosetime()">
                </div>
            </li>
            <li><a href="#" onmouseover="mopen('m7')" onmouseout="mclosetime()">Resources</a>
            	<div id="m7" onmouseover="mcancelclosetime()" onmouseout="mclosetime()">
                </div>
            </li>
        </ul>
    </th>
  </tr>
  <tr>
    <th height="26" scope="col" style="border : 1px solid #e0e0e0;">&nbsp;</th>
  </tr>
</table>

<!--<div align="center" class="header">Header</div>-->