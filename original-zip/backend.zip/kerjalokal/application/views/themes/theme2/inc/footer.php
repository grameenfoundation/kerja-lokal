<table style="border : 1px solid #e0e0e0;" width="950" border="0" align="center">
  <tr>
    <td align="center">&copy; 2011 Infokerja</td>
  </tr>
</table>
</body>
</html>