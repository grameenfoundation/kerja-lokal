<html>
	<head>
		<title></title>
	</head>
	<body>
		<p style="text-align: center;">
			<img alt="Kerja Lokal" src="http://oi43.tinypic.com/2rz6ps6.jpg" style="width: 464px; height: 222px;" /></p>
		<p>
			&nbsp;</p>
		<p>
			<span style="font-family: georgia,serif;"><span style="font-size: 20px;">KERJA LOKAL adalah layanan yang menyediakan beragam informasi pekerjaan menurut kategori yang diinginkan. Sistem KERJA LOKAL secara otomatis akan mencocokkan profil pencari kerja dengan informasi pekerjaan yang paling sesuai, misalnya dengan memperhitungkan faktor kedekatan jarak.</span></span></p>
		<p>
			&nbsp;</p>
		<p>
			<span style="font-family: georgia,serif;">Layanan KERJA LOKAL saat ini tersedia dalam bentuk aplikasi pada hape Esia tipe tertentu (Esia Fun Series &amp; Starlite) yang bertanda khusus logo &quot;USAHAKU&quot;. Layanan ini juga dapat Anda aktifkan melalui SMS dengan mengetik &quot;KERJA INFO&quot; ke 818. </span></p>
		<p>
			<span style="font-family: georgia,serif;">Bagi Perusahaan dan Organisasi yang berminat untuk memasang lowongan pekerjaan, manfaatkan KERJA LOKAL untuk menjangkau pencari kerja dengan GRATIS!</span></p>
		<p>
			<span style="font-family: georgia,serif;">Info selanjutnya hubungi : PT RUMA. Call Center : 021-60908000, 021-60908001, 021-60908002 atau Email : usahaku@ruma.co.id</span></p>
	</body>
</html>
