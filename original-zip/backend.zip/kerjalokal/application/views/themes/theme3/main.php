<!DOCTYPE html>
<html>
<head>
<title><?php echo $title ?></title>

<link href="<?php echo base_url() . "themes/theme3/style.css"; ?>" rel="stylesheet" type="text/css">
<script type="text/javascript" src="<?php echo base_url() . "themes/theme3/jquery.min.js"; ?>" ></script>
<script type="text/javascript" src="<?php echo base_url() . "themes/theme3/jquery-ui.min.js"; ?>" ></script>
<script type="text/javascript">
	$(document).ready(function(){
		$("#featured > ul").tabs({fx:{opacity: "toggle"}}).tabs("rotate", 5000, true);
	});
</script>
</head>
<body style="text-align:center">
<table style="border : 1px solid #e0e0e0;" border="0" width="900" height="798" align="center">
  <tr>
    <td style="border : 1px solid #e0e0e0;" height="25" colspan="3" align="left">&nbsp; RSS | Contact US | Patnership | Sitemap | Follow US | Bookmark & Share</td>
  </tr>
  <tr>
    <td style="border : 1px solid #e0e0e0;" height="74" colspan="3"><?php echo $title ?></td>
  </tr>
  <tr>
    <td style="border : 1px solid #e0e0e0;" height="28" colspan="3">
    	
    </td>
  </tr>
  <tr>
  
  	<!--	FOR IMAGE SLIDE SHOW	-->
    <td height=50%>
    	<div id="featured" >
		  <ul class="ui-tabs-nav">
	        <li class="ui-tabs-nav-item ui-tabs-selected" id="nav-fragment-1"><a href="#fragment-1"><img src="<?php echo base_url() . "themes/theme3/images/image1-small.jpg"; ?>" alt="" /><span>15+ Excellent High Speed Photographs</span></a></li>
	        <li class="ui-tabs-nav-item" id="nav-fragment-2"><a href="#fragment-2"><img src="<?php echo base_url() . "themes/theme3/images/image2-small.jpg"; ?>" alt="" /><span>20 Beautiful Long Exposure Photographs</span></a></li>
	        <li class="ui-tabs-nav-item" id="nav-fragment-3"><a href="#fragment-3"><img src="<?php echo base_url() . "themes/theme3/images/image3-small.jpg"; ?>" alt="" /><span>35 Amazing Logo Designs</span></a></li>
	        <li class="ui-tabs-nav-item" id="nav-fragment-4"><a href="#fragment-4"><img src="<?php echo base_url() . "themes/theme3/images/image4-small.jpg"; ?>" alt="" /><span>Create a Vintage Photograph in Photoshop</span></a></li>
	      </ul>

	    <!-- First Content -->
	    <div id="fragment-1" class="ui-tabs-panel" style="">
			<img src="<?php echo base_url() . "themes/theme3/images/image1.jpg"?>" alt="" />
			 <div class="info" >
				<h2><a href="#" >15+ Excellent High Speed Photographs</a></h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla tincidunt condimentum lacus. Pellentesque ut diam....<a href="#" >read more</a></p>
			 </div>
	    </div>

	    <!-- Second Content -->
	    <div id="fragment-2" class="ui-tabs-panel ui-tabs-hide" style="">
			<img src="<?php echo base_url() . "themes/theme3/images/image2.jpg"?>" alt="" />
			 <div class="info" >
				<h2><a href="#" >20 Beautiful Long Exposure Photographs</a></h2>
				<p>Vestibulum leo quam, accumsan nec porttitor a, euismod ac tortor. Sed ipsum lorem, sagittis non egestas id, suscipit....<a href="#" >read more</a></p>
			 </div>
	    </div>

	    <!-- Third Content -->
	    <div id="fragment-3" class="ui-tabs-panel ui-tabs-hide" style="">
			<img src="<?php echo base_url() . "themes/theme3/images/image3.jpg"?>" alt="" />
			 <div class="info" >
				<h2><a href="#" >35 Amazing Logo Designs</a></h2>
				<p>liquam erat volutpat. Proin id volutpat nisi. Nulla facilisi. Curabitur facilisis sollicitudin ornare....<a href="#" >read more</a></p>
	         </div>
	    </div>

	    <!-- Fourth Content -->
	    <div id="fragment-4" class="ui-tabs-panel ui-tabs-hide" style="">
			<img src="<?php echo base_url() . "themes/theme3/images/image4.jpg"?>" alt="" />
			 <div class="info" >
				<h2><a href="#" >Create a Vintage Photograph in Photoshop</a></h2>
				<p>Quisque sed orci ut lacus viverra interdum ornare sed est. Donec porta, erat eu pretium luctus, leo augue sodales....<a href="#" >read more</a></p>
	         </div>
	    </div>

		</div>
	</div>
    </td>
    <td width="25%">&nbsp;</td>
    <td width="25%">&nbsp;</td>
  </tr>
  <tr>
    <td height="389">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td style="border : 1px solid #e0e0e0;" colspan="3" align="center"><?php echo $footer; ?></td>
  </tr>
</table>
</body>
</html>