<html>
	<head>
		{meta}
		<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>themes/theme1/main.css" />
	</head>
	<body>
		<table width="90%" cellpadding="0" cellspacing="0" border="0">
		<tr>
			<td width="100%">
				<table width="100%" cellpadding="0" cellspacing="0" border="0">
				<tr>
					<td width="70%">{header_menu}</td>
					<td width="30%">{search_box}</td>
				</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td>
				{header}
				<table width=80% border=1 align=center cellpadding=10>
				<tr><td height=100 colspan=2><img src=<?php echo base_url(); ?>themes/theme1/images/christmas.jpg><br></td></tr>
				<tr>
					<td width="70%" bgcolor="#ffeeee">{content}</td>
					<td width="30%" bgcolor="#eeeeff">{sidebar}</td>
				</tr>
				<tr><td height=20 colspan=2><?php echo $footer ?></td></tr>
				</table>
			</td>
		</tr>
		</table>
	</body>
</html>