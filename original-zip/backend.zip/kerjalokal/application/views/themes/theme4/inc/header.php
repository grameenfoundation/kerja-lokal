<?php  if ( ! defined('BASEPATH')) exit('No direct access allowed'); ?>

<!--<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>.:Infokerja:.</title>
<script type="text/javascript" src="<?php echo base_url() . "themes/theme4/js/jquery.js"; ?>"></script>
<script type="text/javascript" src="<?php echo base_url() . "themes/theme4/js/easySlider1.7.js"; ?>"></script>

<script type="text/javascript" src="<?php echo base_url() . "themes/theme4/javascript/dropdown.js"; ?>"></script>
<script type="text/javascript">
	/*	SLIDER FOR SLIDESHOR	*/
	$(document).ready(function(){	
		$("#slider").easySlider({
			auto: true, 
			continuous: true,
			numeric: true
		});
	});	
</script>
<link href="<?php echo base_url() . "themes/theme4/css/style.css"; ?>" rel="stylesheet" type="text/css" media="screen" />	
</head>

<body>

<div id="wrapper">

	<!--	HEADER TOP	-->
	<div id="header">    		
        <div class="menu">
            <ul>
                <li><a href="#">RSS</a></li>
                <li><a href="#">Contact US</a></li>
                <li><a href="#">Patnership</a></li>
                <li><a href="#">Sitemap</a></li>
                <li><a href="#">Bookmark & Share</a></li>
                <li id="float-r">
                <form>
                    <label class="text">Search</label>
                    <input class="searchbox" value="Search" type="text">
                    <button class="searchbtn" title="Search">go</button>
                </form>
                </li>
            </ul>
            <br style="clear:left"/>  
        </div>        
	</div><!-- #header-->
    
    <!--	HEADER TITLE	-->
    <div class="top-header">
    	INFO KERJA
        <ul>
        	<li><a href="#">Bakrie Telecom</a></li>
            <li><a href="#">Grameen Fondation</a></li>
        </ul>
        <ul>
        	<li><a href="#">Qualcomm</a></li>
            <li><a href="#">RUMA</a></li>
        </ul>
    </div>
    
    <!--	HEADER MENU	-->
	<div class="navbar">
		<ul>
			<li><a href="#" >Home</a></li>
			<li><a href="#" id="current">About</a>
				<ul>
					<li><a href="#">Drop Down CSS Menus</a></li>
					<li><a href="#">Horizontal CSS Menus</a></li>
					<li><a href="#">Vertical CSS Menus</a></li>
					<li><a href="#">Dreamweaver Menus</a></li>
			   </ul>
		    </li>
			<li><a href="#">Learn</a>
                <ul>
                    <li><a href="#">Drop Down CSS Menus</a></li>
                    <li><a href="#">Horizontal CSS Menus</a></li>
                    <li><a href="#">Vertical CSS Menus</a></li>
                    <li><a href="#">Dreamweaver Menus</a></li>
                </ul>
            </li>
		  	<li><a href="#">For Employer</a></li>
          	<li><a href="#">Support Forum</a></li>
          	<li><a href="#">News & Event</a></li>
          	<li><a href="#">Resources</a></li>
		</ul> 
	</div>
    <!--	LOGIN FRONT	-->
	<div class="login-header">
    	<ul>
        	<li id="login-form">
                <form>
                    <label class="text">Employer</label>
                    <input class="loginbox" value="User Name" type="text">
                    <input class="loginbox" value="Password" type="text">
                    <button class="searchbtn" title="Search">Login</button>
                    <a href="#">Sign Up Free!</a> ||
                    <a href="#">Take a Tour</a>
                </form>
                </li>
        </ul>
    </div>
	

