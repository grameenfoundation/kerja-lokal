<div id="footer">
	&copy; 2011 Infokerja. All Rights Reserved. Term of Use Privacy Policy
</div><!-- #footer -->

</body>
</html>