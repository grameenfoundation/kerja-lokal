	<div id="middle">

		<div id="container">
			<div id="content">
                
                Highlights
                
                <div id="content-slider">
					
                    <div id="slider">
                        <ul>	
                            <li><a href="#"><img src="<?php echo base_url() . "themes/theme4/images/01.jpg"?>" alt="Css Template Preview" /></a></li>
                            <li><a href="#"><img src="<?php echo base_url() . "themes/theme4/images/02.jpg"?>" alt="Css Template Preview" /></a></li>
                            <li><a href="#"><img src="<?php echo base_url() . "themes/theme4/images/03.jpg"?>" /></a></li>
                            <li><a href="#"><img src="<?php echo base_url() . "themes/theme4/images/04.jpg"?>" alt="Css Template Preview" /></a></li>
                            <li><a href="#"><img src="<?php echo base_url() . "themes/theme4/images/05.jpg"?>" alt="Css Template Preview" /></a></li>			
                        </ul>
                    </div>
                </div>
            Updates    
            <div class="somediv">
                <div class="floatbox">
                <img border="0" src="<?php echo base_url() . "themes/theme4/images/btn_downloadcatalogue.png"?>" width="60" height="60" />
                </div>
                Lorem Ipsum 1<br />
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled...<a href="#">More</a>
			</div>   
            <div class="somediv">
                <div class="floatbox">
                <img border="0" src="<?php echo base_url() . "themes/theme4/images/btn_downloadcatalogue.png"?>" width="60" height="60" />
                </div>
                Lorem Ipsum 2<br />
                when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged...<a href="#">More</a>
			</div>   
            <div class="somediv">
                <div class="floatbox">
                <img border="0" src="<?php echo base_url() . "themes/theme4/images/btn_downloadcatalogue.png"?>" width="60" height="60" />
                </div>
                Lorem Ipsum 3<br />
                It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker...<a href="#">More</a>
			</div>    
			</div><!-- #content-->
            <br style="clear:both" />
            &nbsp;&nbsp;&nbsp;&nbsp;RESOURCES
            <div class="resources">
                <div class="box">
                <img border="0" src="<?php echo base_url() . "themes/theme4/images/btn_downloadcatalogue.png"?>" width="60" height="60" />
                </div>
                Lorem Ipsum 1<br />
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled...<a href="#">More</a>
			</div>   
            
		</div><!-- #container-->

		<div id="sideLeft">
        	How It Works
			<div class="work">
            	<ul>
                    <li id="job-seeker">Use Nice Diagram</li>
                    <li id="job-seeker">
                    	Info Kerja Lorem Ipsum<br />
                        <b>Job Seeker</b><br /> 
                        <b>Job Mentor</b><br /> 
                        <b>Job Employer</b><br /> 
                    </li>
                </ul>
            </div>
            Why Info Kerja
            <div class="info">
            	<ul>
                	<li>
                        Highlight Employer Benefit:<br />
                        <b>Hire Faster</b><br /> 
                        <b>Pre Screening</b><br /> 
                        <b>Search Our Database</b><br /> 
                        <b>Instant Feedback</b><br /> 
                        <b>3 Months Free!</b><br /> 
                    </li>
                    <li>
						Delivered via Mobile Phone with its power                    
                    </li>
                    <li>
                      <form id="form1" name="form1" method="post" action="">
                        <label>
                          <input type="submit" name="button" id="button" value="Download Brochure" />
                          <br />
                          
                        </label>
                        <label>
                          <input type="submit" name="button2" id="button2" value="Take a Tour" /><br />
                        </label>
                        <label>
                          <input type="submit" name="button3" id="button3" value="Registering is Free" />
                        </label>
                      </form>
                    	
                    </li>
                    <li>
                    	Need Assistant?<br />
                        <b>Call 0219292929</b><br />
                        <b>YM : infokerja</b><br />
                        <b>Email : info@nfo-kerja.co.id</b><br />
                        <b>BBM : 82831</b><br />
                    </li>
                </ul>
            </div>
		</div><!-- .sidebar#sideLeft -->

		<div id="sideRight">
			Events
            <div class="event">
            	<ul>
                	<li>Event Info Kerja</li>
                    <li>
                    	20-26 March, 2011<br />
                        <b>HR & Job Seminar, JCC</b><br />
                        02 April, 2011<br />                        
                        <b>Info Kerja Esia launch</b><br />
                        10 - 17 June, 2011
                        <b>West Java Vocational</b><br />
                        <b>School Competition</b><br />
                    </li>                    
              </ul>
                <ul id="event-banner">
                	<li>
                    	Banner 1<br />
                        See What's Hot on Support Forum
                    </li>
                    <li>
                    	Banner 2<br />
                        Article or Resources of the Week (or HR Corner)
                    </li>
                    <li>
                    	Banner 3<br />
                        Client / Past Employer Testimonial
                    </li>
                </ul>
            </div>
            Follow US
			<div class="social">
            	<ul>
                    <li>Logo Facebook</li>                    
                </ul>
                <ul>
                	<li>
                    	Subcribe to our Newsletter<br />                        
                    </li>
                </ul>
            </div>
		</div><!-- .sidebar#sideRight -->

	</div><!-- #middle-->

</div>

<!-- #wrapper -->