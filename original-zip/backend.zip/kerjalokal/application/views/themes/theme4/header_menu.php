<table width="80%" border="0">
<?php
	$header_menu = explode($header_menu, ",");
	
?>
</table>