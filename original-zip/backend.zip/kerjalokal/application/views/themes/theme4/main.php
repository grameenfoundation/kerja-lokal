<?= $header ?>
<div>
<?= $content ?>
</div>
<div>
<?= $footer ?>
</div>
