				<div class="leftmenu_group">
					<div class="leftmenu_title">COMPANY</div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/company/add">Create New</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/company/manage">Manage</a></div>
				</div>
				<div class="leftmenu_group">
					<div class="leftmenu_title">JOB POSTER</div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/jobposter/add">Create New</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/jobposter/manage">Manage</a></div>
				</div>
				<div class="leftmenu_group">
					<div class="leftmenu_title">JOB SEEKER</div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/jobseeker/add">Create New</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/jobseeker/addjob">Manage Job Subscription</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/jobseeker/manage">Manage</a></div>
				</div>
				<div class="leftmenu_group">
					<div class="leftmenu_title">JOB MENTOR</div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/jobmentor/manage">Manage</a></div>
				</div>
				<div class="leftmenu_group">
					<div class="leftmenu_title">JOB POST</div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/jobpost/add">Create New</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/jobpost/manage">Manage</a></div>
				</div>
