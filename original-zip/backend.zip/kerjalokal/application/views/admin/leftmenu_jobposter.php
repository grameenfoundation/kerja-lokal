				<div class="leftmenu_group">
					<div class="leftmenu_title">JOB POST</div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/jobpost/add">Create New</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/jobpost/manage">Manage</a></div>
				</div>
