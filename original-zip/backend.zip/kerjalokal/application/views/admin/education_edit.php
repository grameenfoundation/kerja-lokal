
<div style="display:table; width:100%;">
<?php
	echo form_open($form_action);
	echo "<input type='hidden' value='".$edu_id."' name='id' id='id' />";
	echo "<div class='row'><div class='cell_key'>".form_label('Education', 'edu_title')."</div>\n";
	echo "<div class='cell_val'>".form_input("edu_title", $edu_title ,"size=40 maxlength=100").form_error('edu_title', '<div class="form_error" style="color:red">', '</div>')."</div></div>\n";
	echo "<div class='row'><div class='cell_key'></div><div class='cell_val'>".form_submit("submit", "Submit")."</div>";
	echo form_close();
?>
</div>
