		<a href=<?php echo base_url(); ?>admin/>Home</a> |
		<a href="<?php echo base_url(); ?>admin/themes/template">Manage Themes</a> |
		<a href="<?php echo base_url(); ?>admin/contents">Manage Contents</a> |
		<a href="<?php echo base_url(); ?>admin/help">Help</a> |
		<a href="<?php echo base_url(); ?>admin/logout">logout</a>
