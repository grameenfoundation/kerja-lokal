<?php
	echo form_open('admin');
	echo form_label('Username', 'username')."<br>";
	echo form_input("username","" ,"size=40")."<br><br>";
	echo form_label('Password', 'password')."<br>";
	echo form_password("password","" ,"size=40")."<br><br>";
	echo form_submit("submit", "Submit");
	echo form_close();
?>

<br><br><a href="<?php echo base_url(); ?>admin/main/forget_password">Forget Password</a>