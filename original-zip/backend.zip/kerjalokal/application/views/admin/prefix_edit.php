
<?php
	echo form_open($form_action);
	echo "<div class='row'><div class='cell_key'>".form_label('Area prefix', 'opprefix')."</div>\n";
	echo "<div class='cell_val'>".form_input("opprefix", $opprefix ,"size=40 maxlength=100").form_error('opprefix', '<div class="form_error" style="color:red">', '</div>')."</div></div>\n";
	echo "<div class='row'><div class='cell_key'></div><div class='cell_val'>".form_submit("submit", "Submit")."</div>";
	echo form_close();
?>
