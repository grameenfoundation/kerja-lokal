<?php
	echo form_open('admin/main/forget_password');
	echo form_label('Username or E-mail', 'username')."<br>";
	echo form_input("username","" ,"size=40")."<br><br>";
	echo form_submit("submit", "Submit");
	echo form_close();
?>

