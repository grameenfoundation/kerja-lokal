				<div class="leftmenu_group">
					<div class="leftmenu_title">COMPANY</div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/company/add">Create New</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/company/manage">Manage</a></div>
				</div>
				<div class="leftmenu_group">
					<div class="leftmenu_title">JOB POSTER</div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/jobposter/add">Create New</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/jobposter/manage">Manage</a></div>
				</div>
				<div class="leftmenu_group">
					<div class="leftmenu_title">JOB SEEKER</div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/jobseeker/add">Create New Job Seeker</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/jobseeker/manage">Manage Job Seeker</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/jobseeker/addjob">Add Job Subscription</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/jobseeker/updatejob">Manage Job Subscription</a></div>
				</div>
				<div class="leftmenu_group">
					<div class="leftmenu_title">JOB MENTOR</div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/jobmentor/manage">Manage</a></div>
				</div>
				<div class="leftmenu_group">
					<div class="leftmenu_title">JOB POST</div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/jobpost/add">Create New</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/jobpost/manage">Manage</a></div>
				</div>
				<div class="leftmenu_group">
					<div class="leftmenu_title">LOG</div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/log/web">Web Access</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/log/dms">DMS Access</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/log/sms">SMS Access</a></div>
				</div>
				<!--
				<div class="leftmenu_group">
					<div class="leftmenu_title">Job Scheduling</div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/jobsend/plan">Delivery Plan</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/jobsend/report">Delivery Report</a></div>
				</div>
				-->
				<div class="leftmenu_group">
					<div class="leftmenu_title">MASTER SETUP</div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/master/location/add">Add Location</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/master/location/manage">Manage Location</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/jobcategory/add">Add Job Category</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/jobcategory/manage">Manage Job Category</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/education/add">Add Education</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/education/manage">Manage Education</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/master/industry/add">Add Industry</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/master/industry/manage">Manage Industry</a></div>
				</div>
				<div class="leftmenu_group">
					<div class="leftmenu_title">GENERAL SETTINGS</div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/master/area">Service area</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/tarif">Set tarrif</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/jobmatch/manage">Job Matching</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/jobsupply">Job Supply</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/country/manage">Manage Internationalization</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/country/add">Add Internationalization</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/broadcast/manage_email">Manage Email Broadcast</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/broadcast/add_email">Add Email Broadcast</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/broadcast/manage_sms">Manage SMS Broadcast</a></div>
					<div class="leftmenu_subtitle"><a href="<?php echo base_url(); ?>admin/broadcast/add_sms">Add SMS Broadcast</a></div>
				</div>
				