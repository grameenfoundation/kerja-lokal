<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Main extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		session_start();
		$this->load->model('Mmain');
	}
	
	function index()
	{
		echo "hello world";
	}	
}

/* End of file welcome.php */
/* Location: ./system/application/controllers/welcome.php */