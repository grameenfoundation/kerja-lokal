<html>
   <head>
      <title><?php echo $title ?></title>
      <link rel="stylesheet" type="text/css" href="main.css" />
   </head>
   <body style="text-align:center">
		<?php //echo $header ?>
		{header}
		<table width=80% border=1 align=center cellpadding=10>
		<tr><td height=100 colspan=2><img src=<?php echo base_url(); ?>themes/theme1/images/christmas.jpg><br><?php echo $title ?></td></tr>
		<tr>
			<td width="70%" bgcolor="#ffeeee">{content}</td>
			<td width="30%" bgcolor="#eeeeff">{sidebar}</td>
		</tr>
		<tr><td height=20 colspan=2><?php echo $footer ?></td></tr>
		</table>
   </body>
</html>