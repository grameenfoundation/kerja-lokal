<?php
    $config['hostname'] = 'localhost';
    $config['username'] = 'root';
    $config['password'] = '';
    $config['port'] = 21;
    $config['passive'] = FALSE;
    $config['debug'] = TRUE;
?>